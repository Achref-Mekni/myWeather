package com.example.myweather

import android.os.Bundle
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.myweather.data.WeatherResponse
import com.example.myweather.network.WeatherAPI
import kotlinx.android.synthetic.main.activity_details.*
import org.w3c.dom.Text
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class DetailsActivity: AppCompatActivity() {



    private var weatherData: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)
        val city = intent.getStringExtra("name")
        weatherData = findViewById(R.id.weath);
        getCurrentData(city)

    }
    fun getCurrentData(city:String) {
        var retrofit = Retrofit.Builder()
            .baseUrl("https://api.openweathermap.org/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        var service = retrofit. create (WeatherAPI::class.java)
        val call = service.getWeatherDetails(city,
            "metric",
            "e9029cd4e87a1aa29bca91afd7442a6b"
        )

        call.enqueue( object: Callback<WeatherResponse> {

            override fun  onResponse(
                 call: Call<WeatherResponse>,
                 response: Response<WeatherResponse>
            ) {
                if (response.code() == 200) {
                    var weatherResponse: WeatherResponse? = response.body()
                    assert(weatherResponse != null)

                    var stringBuilder: String = "Country: " +
                            weatherResponse?.sys?.country +
                            "\n" +"\n" +
                            "Coordinates: "+
                            weatherResponse?.coord?.lat +"  "+ weatherResponse?.coord?.lon+
                            "\n" +"\n" +
                            "Weather: "+
                            weatherResponse?.weather?.get(0)?.main+
                            "\n" +"\n" +
                            "Description: "+
                            weatherResponse?.weather?.get(0)?.description+
                            "\n" +"\n" +
                            "Temperature: " +
                            weatherResponse?.main?.temp +
                            "\n" +"\n" +
                            "Temperature(Min): " +
                            weatherResponse?.main?.temp_min +
                            "\n" +"\n" +
                            "Temperature(Max): " +
                            weatherResponse?.main?.temp_max +
                            "\n" +"\n" +
                            "Humidity: " +
                            weatherResponse?.main?.humidity +
                            "\n" +"\n" +
                            "Pressure: " +
                            weatherResponse?.main?.pressure

                    weatherData?.setText(stringBuilder)
                    println("AAAAAAAAAAAAAAAAAAAAAAA: ${"http://openweathermap.org/img/w/"+weatherResponse?.weather?.get(0)?.icon+".png"}")
                    Glide.with(this@DetailsActivity).load("http://openweathermap.org/img/w/"+weatherResponse?.weather?.get(0)?.icon+".png").into(weather_icon)
                }

            }

            override fun onFailure(call: Call<WeatherResponse>,  t:Throwable) {
                weatherData?.setText(t.message);
            }

        })
    }

}
