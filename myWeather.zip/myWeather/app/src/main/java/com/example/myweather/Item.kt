package com.example.myweather

data class Item (
var nameOfcity:String
)