package com.example.myweather

import android.content.Context

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.shop.ListAdapter

import kotlinx.android.synthetic.main.activity_main.*



class MainActivity : AppCompatActivity() {


    lateinit var drawerLayout: DrawerLayout
    private lateinit var adapter: NavigationRVAdapter

    var new = Item("Paris")
    companion object {
        var listItems: MutableList<Item> = mutableListOf()

    }


    private var items = arrayListOf(
        NavigationItemModel( "Add City"),
        NavigationItemModel( "About Us" )

    )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        drawerLayout = findViewById(R.id.drawer_layout)

        //listItems.add(new)
        // Set the toolbar
        setSupportActionBar(toolbar)
        println(listItems.size)


        // Setup Recyclerview's Layout
        navigation_rv.layoutManager = LinearLayoutManager(this)
        navigation_rv.setHasFixedSize(true)

        // Add Item Touch Listener
        navigation_rv.addOnItemTouchListener(RecyclerTouchListener(this, object : ClickListener {
            override fun onClick(view: View, position: Int) {
                when (position) {
                    0 -> {
                        addFragment ().show(supportFragmentManager, "Dialog")
                    }
                    1 -> {
                        Toast.makeText(applicationContext,"Name:Achref Mekni     Neptun:RMPSYJ  ", Toast.LENGTH_SHORT).show()
                    }
                }
                // Don't highlight the 'Profile' and 'Like us on Facebook' item row
                if (position != 6 && position != 4) {
                    updateAdapter(position)
                }
                Handler().postDelayed({
                    drawerLayout.closeDrawer(GravityCompat.START)
                }, 200)
            }
        }))
        updateAdapter(0)

        // Set 'Home' as the default fragment when the app starts

        val toggle: ActionBarDrawerToggle = object : ActionBarDrawerToggle(this, drawerLayout,toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close) {
            override fun onDrawerClosed(drawerView: View) {
                // Triggered once the drawer closes
                super.onDrawerClosed(drawerView)
                try {
                    val inputMethodManager =
                        getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    inputMethodManager.hideSoftInputFromWindow(currentFocus?.windowToken, 0)
                } catch (e: Exception) {
                    e.stackTrace
                }
            }

            override fun onDrawerOpened(drawerView: View) {
                // Triggered once the drawer opens
                super.onDrawerOpened(drawerView)
                try {
                    val inputMethodManager =
                        getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    inputMethodManager.hideSoftInputFromWindow(currentFocus!!.windowToken, 0)
                } catch (e: Exception) {
                    e.stackTrace
                }
            }
        }
        drawerLayout.addDrawerListener(toggle)

        toggle.syncState()
        navigation_header_img.setImageResource(R.drawable.logo)


        // Set background of Drawer
        navigation_layout.setBackgroundColor(ContextCompat.getColor(this, R.color.colorPrimary))
        list_recycler_view.apply {
            list_recycler_view.layoutManager = LinearLayoutManager(this@MainActivity)
            list_recycler_view.adapter = ListAdapter(listItems, this@MainActivity)
            list_recycler_view.scheduleLayoutAnimation()
            list_recycler_view.adapter?.notifyDataSetChanged()
        }





    }
    override fun onResume() {

        super.onResume()

        list_recycler_view.apply {
            list_recycler_view.layoutManager = LinearLayoutManager(this@MainActivity)
            list_recycler_view.adapter = ListAdapter(listItems, this@MainActivity)
            list_recycler_view.scheduleLayoutAnimation()

        }


    }




    private fun updateAdapter(highlightItemPos: Int) {
        adapter = NavigationRVAdapter(items, highlightItemPos)
        navigation_rv.adapter = adapter
        adapter.notifyDataSetChanged()
    }

}
