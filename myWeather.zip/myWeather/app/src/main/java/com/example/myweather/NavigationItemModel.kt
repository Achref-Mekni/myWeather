package com.example.myweather

data class NavigationItemModel( var title: String)