package com.example.shop

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Insets.add
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.ContextCompat

import androidx.recyclerview.widget.RecyclerView
import com.example.myweather.DetailsActivity
import com.example.myweather.Item
import com.example.myweather.MainActivity

import com.example.myweather.R



class ListAdapter(private val list: MutableList<Item>, private val context: Context) : RecyclerView.Adapter<ItemViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return ItemViewHolder(inflater, parent)
    }



    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val product: Item = list[position]
        holder.bind(product, context)

    }

    public fun addTodo(city: Item) {
        list.add(city)
        notifyItemInserted(list.lastIndex)
    }

    override fun getItemCount(): Int = list.size

}

class ItemViewHolder(inflater: LayoutInflater, parent: ViewGroup) : RecyclerView.ViewHolder(inflater.inflate(R.layout.list_item, parent, false)) {


    private var cityView: TextView? = null

    private var detailsView: Button? = null
    private var deleteCity:Button?=null
    private var recView:RecyclerView?=null


    init {
        cityView = itemView.findViewById(R.id.city_name)
        detailsView = itemView.findViewById(R.id.btn_details)
        deleteCity= itemView.findViewById(R.id.btn_delete)
        recView = itemView.findViewById(R.id.list_recycler_view)

    }

    fun bind(product: Item, context: Context) {
        cityView?.text = product.nameOfcity


        deleteCity?.setOnClickListener {

            MainActivity.listItems.remove(product)
            val intent = Intent(context, MainActivity::class.java)
            ContextCompat.startActivity(context, intent, null)

        }

        detailsView?.setOnClickListener {


            val intent = Intent(context, DetailsActivity::class.java)
            intent.putExtra("name", product.nameOfcity)
            ContextCompat.startActivity(context, intent, null)


        }


    }



}