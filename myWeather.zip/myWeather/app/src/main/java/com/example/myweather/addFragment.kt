package com.example.myweather

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment

import kotlinx.android.synthetic.main.custom_dialog.*

class addFragment: DialogFragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        getDialog()!!.getWindow()?.setBackgroundDrawableResource(R.drawable.round_corner);

        return inflater.inflate(R.layout.custom_dialog, container, false)

    }

    override fun onStart() {
        super.onStart()
        val width = (resources.displayMetrics.widthPixels * 0.85).toInt()
        val height = (resources.displayMetrics.heightPixels * 0.40).toInt()
        dialog!!.window?.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT)

        var name:String=""
        et_cityname.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {

                name = s.toString()

            }

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {


            }
        })
        btn_add.setOnClickListener {
            var new = Item(name)
            println(MainActivity.listItems.size)
            MainActivity.listItems.add(new)
            println(name)
            println(MainActivity.listItems.size)

            dialog!!.dismiss()
        }


        btn_cancel.setOnClickListener {
            dialog!!.dismiss()
        }

    }



}
